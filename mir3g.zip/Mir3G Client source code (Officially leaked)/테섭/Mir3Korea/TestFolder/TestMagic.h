// TestMagic.h

#ifndef _TESTMAGIC_H_
#define _TESTMAGIC_H_


#endif