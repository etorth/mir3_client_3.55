// TestMagic.cpp

#include "stdAfx.h"
